package com.sentimentanalysis;

public class ProductObj {
	public String productName = new String();
	public Integer startOffset;
	public Integer endOffset;
}
