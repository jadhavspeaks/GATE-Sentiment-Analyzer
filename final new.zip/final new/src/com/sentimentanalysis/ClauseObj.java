package com.sentimentanalysis;

public class ClauseObj {
	public String clauseContent = new String();
	public String clauseSubject = new String();
	public String clauseObject = new String();
	public String clauseVerb = new String();
	public String clauseVoice = new String();
	public String clauseString = new String();
}
