package com.sentimentanalysis;

public class SentenceChunk {
	private String entity;
	private String sentenceChunk;
	/**
	 * @return the entity
	 */
	public String getEntity() {
		return entity;
	}
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity;
	}
	/**
	 * @return the sentenceChunk
	 */
	public String getSentenceChunk() {
		return sentenceChunk;
	}
	/**
	 * @param sentenceChunk the sentenceChunk to set
	 */
	public void setSentenceChunk(String sentenceChunk) {
		this.sentenceChunk = sentenceChunk;
	}
}
